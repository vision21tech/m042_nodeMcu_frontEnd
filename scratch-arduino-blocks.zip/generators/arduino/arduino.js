/**
 * Visual Blocks Language
 *
 * Copyright 2020 Arthur Zheng.
 * https://github.com/zhengyangliu/scratch-blocks
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use strict';

goog.provide('Blockly.Arduino.arduino');

goog.require('Blockly.Arduino');

//////////////////////////////////////////////////////////////////////
Blockly.Arduino['arduino_esp8266_digital_write'] = function (block) {
    var pinBlock = block.getInputTargetBlock('PIN');
    var arg0 = pinBlock ? Blockly.Arduino.valueToCode(block, 'PIN', Blockly.Arduino.ORDER_UNARY_POSTFIX) || pinBlock.getFieldValue('digital_pins') || '0' : '0';
    
    var onOffBlock = block.getInputTargetBlock('ON_OFF');
    var arg1 = onOffBlock ? Blockly.Arduino.valueToCode(block, 'ON_OFF', Blockly.Arduino.ORDER_UNARY_POSTFIX) || (onOffBlock.getFieldValue('on_off') === '1' ? 'HIGH' : 'LOW') || 'LOW' : 'LOW';

    var code = "digitalWrite(" + arg0 + ", " + arg1 + ");\n";
    return code;
};

Blockly.Arduino['arduino_esp8266_set_bluetooth'] = function (block) {
    var arg0 = Blockly.Arduino.valueToCode(block, 'TX', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 0;
    var arg1 = Blockly.Arduino.valueToCode(block, 'RX', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 0;

    Blockly.Arduino.includes_['arduino_esp8266_set_bluetooth'] = '#include <SoftwareSerial.h>';
    Blockly.Arduino.definitions_['arduino_esp8266_set_bluetooth'] = "SoftwareSerial bt(" + arg0 + ", " + arg1 + ")";

    return '';
};

Blockly.Arduino['arduino_esp8266_set_bluetooth_buadrate'] = function (block) {
    var arg0 = block.getFieldValue('BUADRATE') || '0';
    var code = "bt.begin(" + arg0 + ");\n";

    return code;
}

Blockly.Arduino['arduino_esp8266_bluetooth_available'] = function (block) {
    var code = "bt.available()";
    // boolean이나 reporter 블럭들은 아래와 같이 리턴해야함.
    return [code, Blockly.Arduino.ORDER_ATOMIC];
}

Blockly.Arduino['arduino_esp8266_bluetooth_write'] = function (block) {
    var arg0 = Blockly.Arduino.valueToCode(block, 'VALUE', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '0';
    var code = "bt.write(" + arg0 + ");\n";

    return code;
}

Blockly.Arduino['arduino_esp8266_bluetooth_read'] = function (block) {
    var code = "bt.read()";

    return [code, Blockly.Arduino.ORDER_ATOMIC];
}

Blockly.Arduino['arduino_esp8266_set_serial_buadrate'] = function (block) {
    var arg0 = block.getFieldValue('BUADRATE') || '0';
    var code = "Serial.begin(" + arg0 + ");\n";

    return code;
}

Blockly.Arduino['arduino_esp8266_serial_available'] = function (block) {
    var code = "Serail.available()";

    return [code, Blockly.Arduino.ORDER_ATOMIC];
}

Blockly.Arduino['arduino_esp8266_serial_read'] = function (block) {
    var code = "Serial.read()";

    return [code, Blockly.Arduino.ORDER_ATOMIC];;
}

Blockly.Arduino['arduino_esp8266_serial_print'] = function (block) {
    var arg0 = Blockly.Arduino.valueToCode(block, 'VALUE', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '0';
    var arg1 = block.getFieldValue('LINE') || 'true';
    var code = '';
    if(arg1 === 'true'){
        code = "Serial.println((char)"+ arg0+");\n";
    }else{
        code = "Serial.print((char)"+ arg0+");\n";
    }

    return code;
}

Blockly.Arduino['arduino_esp8266_set_neopixel'] = function (block) {
    var arg0 = Blockly.Arduino.valueToCode(block, 'COUNT', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '0';
    var pinBlock = block.getInputTargetBlock('PIN');
    var arg1 = pinBlock ? Blockly.Arduino.valueToCode(block, 'PIN', Blockly.Arduino.ORDER_UNARY_POSTFIX) || pinBlock.getFieldValue('digital_pins') || '0' : '0';

    var code =
        'neo.setBrightness(255);\n' +
        'neo.begin();\n'+
        'neo.show();\n';

    Blockly.Arduino.includes_['arduino_esp8266_set_neopixel'] = '#include <Adafruit_NeoPixel.h>';
    Blockly.Arduino.definitions_['arduino_esp8266_set_neopixel'] = "Adafruit_NeoPixel neo = Adafruit_NeoPixel(" + arg0 + ", " + arg1 + ", NEO_GRB + NEO_KHZ800);";

    return code;
}

Blockly.Arduino['arduino_esp8266_set_neopixel_color'] = function (block) {
    var arg0 = Blockly.Arduino.valueToCode(block, 'COUNT', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '0';
    const colour = Blockly.Arduino.valueToCode(block, 'COLOR', Blockly.Arduino.ORDER_NONE).replace('#', '');
    const red = parseInt(colour.substring(0, 2), 16);
    const green = parseInt(colour.substring(2, 4), 16);
    const blue = parseInt(colour.substring(4, 6), 16);

    console.log("arg1 : " + red);
    console.log("arg2 : " + green);
    console.log("arg3 : " + blue);

    var code =
        'for(int i = 0; i < ' + (Number(arg0)) + '; i++){\n' +
        '   neo.setPixelColor(i, ' + red + ', ' + green + ', ' + blue + ');\n' +
        '}\n'+
        'neo.show();\n';
    return code;
}

Blockly.Arduino['arduino_esp8266_set_neopixel_color_typing'] = function (block) {
    var arg0 = Blockly.Arduino.valueToCode(block, 'COUNT', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '0';
    var arg1 = Blockly.Arduino.valueToCode(block, 'RED', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '0';
    var arg2 = Blockly.Arduino.valueToCode(block, 'GREEN', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '0';
    var arg3 = Blockly.Arduino.valueToCode(block, 'BLUE', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '0';
    console.log("arg0 : " + typeof (Number(arg0)+1));
    var code =
        'for(int i = 0; i < ' + (Number(arg0)) + '; i++){\n' +
        '   neo.setPixelColor(i, ' + arg1 + ', ' + arg2 + ', ' + arg3 + ');\n' +
        '}\n'+
        'neo.show();\n';

    return code;
}

Blockly.Arduino['arduino_esp8266_all_neopixel_off'] = function (block) {
    var code =
        'neo.clear();\n' +
        'neo.show();\n'

    return code;
}
//////////////////////////////////////////////////////////////////////

Blockly.Arduino['arduino_pin_setPinMode'] = function (block) {
  var arg0 = block.getFieldValue('PIN') || '0';
  var arg1 = block.getFieldValue('MODE') || 'INPUT';
  var code = "pinMode(" + arg0 + ", " + arg1 + ");\n";
  return code;
};

Blockly.Arduino['arduino_pin_setDigitalOutput'] = function (block) {
  var arg0 = block.getFieldValue('PIN') || '0';
  var arg1 = Blockly.Arduino.valueToCode(block, 'LEVEL', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 'LOW';
  var code = "digitalWrite(" + arg0 + ", " + arg1 + ");\n";
  return code;
};

Blockly.Arduino['arduino_pin_menu_level'] = function (block) {
  var code = block.getFieldValue('level') || 'LOW';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino['arduino_pin_setPwmOutput'] = function (block) {
  var arg0 = block.getFieldValue('PIN') || '0';
  var arg1 = Blockly.Arduino.valueToCode(block, 'OUT', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 0;
  var code = "analogWrite(" + arg0 + ", " + arg1 + ");\n";
  return code;
};

Blockly.Arduino['arduino_pin_readDigitalPin'] = function (block) {
  var arg0 = block.getFieldValue('PIN') || '0';
  var code = "digitalRead(" + arg0 + ")";
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino['arduino_pin_readAnalogPin'] = function (block) {
  var arg0 = block.getFieldValue('PIN') || 'A1';
  var code = "analogRead(" + arg0 + ")";
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};


// Ultrasonic
Blockly.Arduino['arduino_pin_setPinTrigger'] = function (block) {
  var arg0 = block.getFieldValue('PIN') || '0';
  Blockly.Arduino.definitions_['definitions_ultrasonic_setTrigger' + arg0] =
    '#define PIN_TRIGGER         ' + arg0 + '   // TRIGGER PIN';
  var code = '';
  return code;
};

Blockly.Arduino['arduino_pin_setPinEcho'] = function (block) {
  var arg0 = block.getFieldValue('PIN') || '0';
  Blockly.Arduino.definitions_['definitions_ultrasonic_setEcho' + arg0] =
    '#define PIN_ECHO            ' + arg0 + '   // ECHO PIN';
  var code = '';
  return code;
};

Blockly.Arduino['arduino_pin_getDistance'] = function (block) {
  Blockly.Arduino.customFunctions_['definitions_pin_getDistance'] =
    '#include <Ultrasonic.h>\n' +
    'Ultrasonic ultrasonic(PIN_TRIGGER, PIN_ECHO);\n' +
    'int distance;';

  var code = 'distance = ultrasonic.read();\n';
  return code;
};

Blockly.Arduino['arduino_pin_readDistance'] = function (block) {
  var code = 'distance';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};
// End of Ultrasonic

// Buzzer
Blockly.Arduino['arduino_pin_setPinBuzzer'] = function (block) {
  var arg0 = block.getFieldValue('PIN') || '0';
  Blockly.Arduino.definitions_['definitions_buzzer_setBuzzer' + arg0] =
    '#define PIN_BUZZER         13   // BUZZER PIN\n\n' +
    'void set_tone(float noteFrequency, long noteDuration, int silentDuration) {\n' +
    '    tone(PIN_BUZZER, noteFrequency, noteDuration);\n' +
    '    delay(noteDuration);\n' +
    '    delay(silentDuration);\n' +
    '}\n\n' +
    'void bend_tones(float startFrequency, float endFrequency, float step, long noteDuration, int silentDuration) {\n' +
    '    if (startFrequency < endFrequency) {\n' +
    '        for (int i = startFrequency; i < endFrequency; i += step) {\n' +
    '            set_tone(i, noteDuration, silentDuration);\n' +
    '        }\n' +
    '    } else {\n' +
    '        for (int i = startFrequency; i > endFrequency; i -= step) {\n' +
    '            set_tone(i, noteDuration, silentDuration);\n' +
    '        }\n' +
    '    }\n' +
    '};';
  var code = '';
  return code;
};

Blockly.Arduino['arduino_pin_setTone'] = function (block) {
  var arg0 = block.getFieldValue('TONE');
  // var arg0 = Blockly.Arduino.valueToCode(block, 'TONE', Blockly.Arduino.ORDER_NONE);
  var arg1 = Blockly.Arduino.valueToCode(block, 'DURATION', Blockly.Arduino.ORDER_NONE) || 200;
  var arg2 = Blockly.Arduino.valueToCode(block, 'SILENT', Blockly.Arduino.ORDER_NONE) || 500;

  var code = 'set_tone(' + arg0 + ', ' + arg1 + ', ' + arg2 + ');\n';
  return code;
};

Blockly.Arduino['arduino_pin_bendTones'] = function (block) {
  var arg0 = block.getFieldValue('INITIALTONE');
  var arg1 = block.getFieldValue('FINALTONE');
  var arg2 = Blockly.Arduino.valueToCode(block, 'STEP', Blockly.Arduino.ORDER_NONE) || 20;
  var arg3 = Blockly.Arduino.valueToCode(block, 'DURATION', Blockly.Arduino.ORDER_NONE) || 100;
  var arg4 = Blockly.Arduino.valueToCode(block, 'SILENT', Blockly.Arduino.ORDER_NONE) || 0;

  var code = 'bend_tones(' + arg0 + ', ' + arg1 + ', ' + arg2 + ', ' + arg3 + ', ' + arg4 + ');\n';
  return code;
};
// End of Buzzer

Blockly.Arduino['arduino_pin_setServoOutput'] = function (block) {
  var arg0 = block.getFieldValue('PIN') || 'A1';
  var arg1 = Blockly.Arduino.valueToCode(block, 'OUT', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 0;

  Blockly.Arduino.includes_['include_servo'] = '#include <Servo.h>';
  Blockly.Arduino.definitions_['definitions_servo' + arg0] = 'Servo servo_' + arg0 + ';';
  Blockly.Arduino.setups_['setups_servo' + arg0] = 'servo_' + arg0 + '.attach' + '(' + arg0 + ');';

  var code = 'servo_' + arg0 + '.write' + '(' + arg1 + ');\n';
  return code;
};

Blockly.Arduino['arduino_pin_attachInterrupt'] = function (block) {
  var arg0 = block.getFieldValue('PIN') || '2';
  var arg1 = block.getFieldValue('MODE') || 'RISING';

  var branch = Blockly.Arduino.statementToCode(block, 'SUBSTACK');
  branch = Blockly.Arduino.addLoopTrap(branch, block.id);

  Blockly.Arduino.definitions_['definitions_ISR_' + arg1 + arg0] =
    'ISR_' + arg1 + '_' + arg0 + '() {\n' + branch + '}';

  var code = 'attachInterrupt(digitalPinToInterrupt(' + arg0 + '), ISR_' + arg1 + '_' + arg0 + ', ' + arg1 + ');\n';
  return code;
};

Blockly.Arduino['arduino_pin_detachInterrupt'] = function (block) {
  var arg0 = block.getFieldValue('PIN') || '2';

  var code = 'detachInterrupt(digitalPinToInterrupt(' + arg0 + ');\n';
  return code;
};

Blockly.Arduino['arduino_serial_serialBegin'] = function (block) {
  var arg0 = block.getFieldValue('VALUE') || '9600';

  var code = 'Serial.begin(' + arg0 + ');\n';
  return code;
};

Blockly.Arduino['arduino_serial_serialPrint'] = function (block) {
  var arg0 = Blockly.Arduino.valueToCode(block, 'VALUE', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '';
  var eol = block.getFieldValue('EOL') || 'warp';
  var code = '';
  if (eol === 'warp') {
    code = 'Serial.println(' + arg0 + ');\n';
  } else {
    code = 'Serial.print(' + arg0 + ');\n';
  }
  return code;
};

Blockly.Arduino['arduino_serial_serialAvailable'] = function () {
  var code = 'Serial.available()';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino['arduino_serial_serialReadData'] = function () {
  var code = 'Serial.read()';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino['arduino_serial_multiSerialBegin'] = function (block) {
  var arg0 = block.getFieldValue('NO') || '0';
  var arg1 = block.getFieldValue('VALUE') || '9600';

  var code;
  if (arg0 === '0') {
    arg0 = '';
  }
  code = 'Serial' + arg0 + '.begin(' + arg1 + ');\n';
  return code;
};

Blockly.Arduino['arduino_serial_multiSerialPrint'] = function (block) {
  var arg0 = block.getFieldValue('NO') || '0';
  var arg1 = Blockly.Arduino.valueToCode(block, 'VALUE', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '';
  var eol = block.getFieldValue('EOL') || 'warp';

  var code;
  if (arg0 === '0') {
    arg0 = '';
  }
  if (eol === 'warp') {
    code = 'Serial' + arg0 + '.println(' + arg1 + ');\n';
  } else {
    code = 'Serial' + arg0 + '.print(' + arg1 + ');\n';
  }
  return code;
};

Blockly.Arduino['arduino_serial_multiSerialAvailable'] = function (block) {
  var arg0 = block.getFieldValue('NO') || '0';
  var code;
  if (arg0 === '0') {
    arg0 = '';
  }

  var code = 'Serial' + arg0 + '.available()';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino['arduino_serial_multiSerialReadAByte'] = function (block) {
  var arg0 = block.getFieldValue('NO') || '0';
  var code;
  if (arg0 === '0') {
    arg0 = '';
  }

  var code = 'Serial' + arg0 + '.read()';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino['arduino_sensor_runningTime'] = function () {
  var code = "millis()";
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino['arduino_data_dataMap'] = function (block) {
  var arg0 = Blockly.Arduino.valueToCode(block, 'DATA', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 0;
  var arg1 = Blockly.Arduino.valueToCode(block, 'ARG0', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 1;
  var arg2 = Blockly.Arduino.valueToCode(block, 'ARG1', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 100;
  var arg3 = Blockly.Arduino.valueToCode(block, 'ARG2', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 1;
  var arg4 = Blockly.Arduino.valueToCode(block, 'ARG3', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 1000;

  var code = 'map(' + arg0 + ', ' + arg1 + ', ' + arg2 + ', ' + arg3 + ', ' + arg4 + ')';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino['arduino_data_dataConstrain'] = function (block) {
  var arg0 = Blockly.Arduino.valueToCode(block, 'DATA', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 0;
  var arg1 = Blockly.Arduino.valueToCode(block, 'ARG0', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 1;
  var arg2 = Blockly.Arduino.valueToCode(block, 'ARG1', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 100;

  var code = 'constrain(' + arg0 + ', ' + arg1 + ', ' + arg2 + ')';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino['arduino_data_dataConvert'] = function (block) {
  var arg0 = Blockly.Arduino.valueToCode(block, 'DATA', Blockly.Arduino.ORDER_UNARY_POSTFIX) || 0;
  var arg1 = block.getFieldValue('TYPE') || 'INTEGER';

  var code;

  switch (arg1) {
    case 'INTEGER':
      code = 'String(' + arg0 + ').toInt()';
      break;
    case 'DECIMAL':
      code = 'String(' + arg0 + ').toFloat()';
      break;
    case 'STRING':
      code = 'String(' + arg0 + ')';
      break;
  }

  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino['arduino_data_dataConvertASCIICharacter'] = function (block) {
  var arg0 = Blockly.Arduino.valueToCode(block, 'DATA', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '0';

  var code = 'String(char(' + arg0 + '))';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino['arduino_data_dataConvertASCIINumber'] = function (block) {
  var arg0 = Blockly.Arduino.valueToCode(block, 'DATA', Blockly.Arduino.ORDER_UNARY_POSTFIX) || '0';

  var code = 'toascii(String(' + arg0 + ')[0])';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};
