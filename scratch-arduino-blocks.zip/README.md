# scratch-arduino-blocks
[![](https://github.com/OttawaSTEM/scratch-arduino-blocks/actions/workflows/release.yml/badge.svg?branch=main)](https://github.com/OttawaSTEM/scratch-arduino-blocks/actions/workflows/release.yml)
![](https://img.shields.io/github/license/ottawastem/scratch-arduino-gui)

## Development Instructions
```
npm install
npm link
```

# Compile in development
```
venv\Scripts\activate
npm run prepublish
```

# Release
```
commit
npm version patch
merge to main
```