# scratch-arduino-vm
[![](https://github.com/OttawaSTEM/scratch-arduino-vm/actions/workflows/release.yml/badge.svg?branch=main)](https://github.com/OttawaSTEM/scratch-arduino-vm/actions/workflows/release.yml)
![](https://img.shields.io/github/license/ottawastem/scratch-arduino-gui)

Scratch Arduino VM is a library for representing, running, and maintaining the state of computer programs written using [Scratch Arduino Blocks](https://github.com/OttawaSTEM/scratch-arduino-blocks).